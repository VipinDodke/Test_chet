import React, { useState } from 'react';
import {
  Text,
  SafeAreaView,
  View,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
// You can import from local files
import Header from './components/AssetExample';
import SearchBar from './components/searchBar';
import Community from './components/Community';
import IndexList from './components/indexList';
import ChatHouse from './components/ChatHouse';

export default function App() {
  const [tabSelect, setTab] = useState(true);
  const [channel,setChannel] = useState({ id: '2', image: '', name: 'Ram1', subName: 'Ram rawet', data: 80 })
  return (
    <SafeAreaView style={styles.container}>
     {channel? <ChatHouse channel={channel} setChannel={setChannel}/>: <><Header />
      <SearchBar />
      <View style={styles.tabContainer}>
        <TouchableOpacity
          onPress={() => setTab(!tabSelect)}
          style={[
            styles.tabButtons,
            { borderBottomColor: tabSelect ? 'black' : 'blue' },
          ]}>
          <Text style={styles.tabLable}>Index</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => setTab(!tabSelect)}
          style={[
            styles.tabButtons,
            { borderBottomColor: tabSelect ? 'blue' : 'black' },
          ]}>
          <Text style={styles.tabLable}> Community </Text>
        </TouchableOpacity>
      </View>
      <View
        style={{
          flex: 0.8,
          width:'100%',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        {tabSelect ?<Community setChannel={setChannel} /> : <IndexList />}
      </View></>}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: '100%',
    padding: 10,
    alignItems: 'flex-start',
    backgroundColor: 'black',
  },
  subContainer: { width: '100%' },
  tabContainer: {
    flex: 0.1,
    flexDirection: 'row',
    width: '100%',
    alignItems: 'center',
    justifyContent: 'space-evenly',
  },
  tabButtons: {
    flex: 0.5,
    alignItems: 'center',
    borderColor: 'red',
    borderBottomWidth: 5,
  },
  tabLable: { color: 'white', fontSize: 15, fontWeight: '600' },
});
