import React from 'react';
import {View,Text,StyleSheet,Image,TextInput,TouchableOpacity} from 'react-native';
function IndexList (){

return(
  <View style={{}}>
 
  </View>
)
}
export default IndexList;


const styles = StyleSheet.create({
 
  logo: {width:15,height:15}
});