import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  Dimensions,
  TouchableOpacity,
} from 'react-native';

const { width, height } = Dimensions.get('screen');
function ChatHouse({ channel, setChannel }) {
  return (
    <View style={{ width, height }}>
      <View
        style={{
          height: '5%',
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
        <TouchableOpacity
          onPress={() => setChannel(null)}
          style={{
            justifyContent: 'center',
            height: '100%',
            width: '7%',
          }}>
          <Text style={{ fontSize: 35, color: '#00FFFF' }}>{'<'}</Text>
        </TouchableOpacity>

        <View style={{ width: '90%', flexDirection: 'row', justifyContent:'flex-start',alignItems:'center' }}>
          <View
            style={{
              width: 55,
              backgroundColor: 'gray',
              height: 55,
              borderRadius: 55,
              alignSelf: 'center',
              justifyContent: 'center',
            }}
          />
          <View style={{left:'5%' }}>
            <Text style={{ color: 'white', fontSize: 20 }}>{channel.name}</Text>
            <Text style={{ color: 'gray', fontSize: 15 }}>
              {channel.data}/100
            </Text>
          </View>
        </View>
        <View
          style={{ height: 25, width: '5%', justifyContent: 'space-evenly' }}>
          <View
            style={{
              width: 5,
              backgroundColor: 'white',
              height: 5,
              borderRadius: 5,
            }}
          />
          <View
            style={{
              width: 5,
              backgroundColor: 'white',
              height: 5,
              borderRadius: 5,
            }}
          />
          <View
            style={{
              width: 5,
              backgroundColor: 'white',
              height: 5,
              borderRadius: 5,
            }}
          />
        </View>
      </View>
     
    </View>
  );
}

const styles = StyleSheet.create({
  logo: { width: 15, height: 15 },
});

export default ChatHouse;
