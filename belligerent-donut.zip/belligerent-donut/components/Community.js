import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
  FlatList,
  Dimensions,
} from 'react-native';
import icon from '../assets/icon.png';
const { width, height } = Dimensions.get('screen');
const fakeList = [
  { id: '1', image: '', name: 'Ram', subName: 'Ram rawet', data: 85 },
  { id: '2', image: '', name: 'Ram1', subName: 'Ram rawet', data: 80 },
  { id: '3', image: '', name: 'Ram2', subName: 'Ram rawet', data: 50 },
  { id: '4', image: '', name: 'Ram3', subName: 'Ram rawet', data: 15 },
  { id: '5', image: '', name: 'Ram4', subName: 'Ram rawet', data: 18 },
  { id: '6', image: '', name: 'Ram5', subName: 'Ram rawet', data: 45 },
  { id: '7', image: '', name: 'Ram6', subName: 'Ram rawet', data: 57 },
  { id: '8', image: '', name: 'Ram7', subName: 'Ram rawet', data: 45 },
  { id: '9', image: '', name: 'Ram8', subName: 'Ram rawet', data: 25 },
  { id: '10', image: '', name: 'Ram9', subName: 'Ram rawet', data: 5 },
  { id: '11', image: '', name: 'Ram10', subName: 'Ram rawet', data: 56 },
  { id: '12', image: '', name: 'Ram11', subName: 'Ram rawet', data: 85 },
];

function Community({setChannel}) {
  return (
    <View style={{ flex: 1, width: '100%' }}>
      <FlatList
        data={fakeList}
        style={{ flex: 1, width: '100%', height: '100%' }}
        contentContainerStyle={{
          alignItems: 'center',
          justifyContent: 'center',
        }}
        renderItem={({ item, index }) => {
          return (
            <TouchableOpacity
            onPress={()=>setChannel(item)}
              style={{
                width: width,
                paddingVertical: '0.5%',
                alignItems: 'center',
                justifyContent: 'center',
                flexDirection: 'row',
              }}>
              <View style={{ width: '20%' }}>
                <View
                  style={{
                    width: 55,
                    backgroundColor: 'gray',
                    height: 55,
                    borderRadius: 55,
                    alignSelf: 'center',
                    justifyContent: 'center',
                  }}
                />
              </View>
              <View style={{ width: '80%', alignItems: 'center' }}>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    width: '80%',
                  }}>
                  <Text style={{ color: 'white' }}>{item.name}</Text>
                  <Text style={{ color: 'gray' }}>{item.data}/100</Text>
                </View>
                <Text style={{ color: 'gray', width: '80%' }}>
                  {item.subName}
                </Text>
              </View>
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );
}
export default Community;

const styles = StyleSheet.create({
  logo: { width: 15, height: 15 },
});
