import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import icon from '../assets/icon.png';

export default function Header() {
  return (
    <View style={styles.container}>
      <View style={styles.imageContainer} />
      <View>
        <Text style={{ color: 'white' }}>Hellow</Text>
      </View>
      <Image source={icon} style={styles.logo} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#273746',
    height: '8%',
    width: '100%',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection: 'row',
    padding: 2,
  },
  imageContainer: {
    width: '8%',
    height: '60%',
    backgroundColor: 'gray',
    borderRadius: 15,
  },

  logo: { width: 25, height: 25 },
});
