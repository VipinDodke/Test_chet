import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import icon from '../assets/icon.png';
function SearchBar() {
  return (
    <View
      style={{
        width: '95%',
        height: '5%',
        marginVertical: 5,
        borderRadius: 3,
        padding: 5,
        flexDirection: 'row',
        backgroundColor: 'gray',
        alignItems: 'center',
        justifyContent: 'space-between',
        alignSelf: 'center',
      }}>
      <TouchableOpacity>
        <Image source={icon} style={styles.logo} />
      </TouchableOpacity>
      <View style={{ width: '80%' }}>
        <TextInput
          placeHolder={'Search'}
          value={'Search'}
          style={{ color: 'white' }}
        />
      </View>
      <TouchableOpacity>
        <Image source={icon} style={styles.logo} />
      </TouchableOpacity>
    </View>
  );
}
export default SearchBar;

const styles = StyleSheet.create({
  logo: { width: 15, height: 15 },
});
